import 'dart:io';

import 'package:dio/dio.dart';

import '../constants/api_constants.dart';
import '../errors/exception_mapper.dart';
import '../errors/exceptions.dart';
import '../storage/secure_token_storage.dart';
import 'auth_interceptor.dart';
import 'base_response.dart';
import 'session_manager.dart';

/// Configured HTTP client for the HR Mobile API.
///
/// All feature repositories use this client. It:
/// - Points to `ApiConstants.baseUrl`
/// - Attaches Bearer token via [AuthInterceptor]
/// - Parses every response into [BaseResponse<T>]
/// - Converts API error codes into typed Dart exceptions
///
/// Usage:
/// ```dart
/// final client = ApiClient(storage: storage, sessionManager: manager);
/// final response = await client.get<EmployeeProfile>(
///   ApiConstants.profile,
///   fromJson: (json) => EmployeeProfile.fromJson(json),
/// );
/// ```
class ApiClient {
  late final Dio _dio;
  final SessionManager sessionManager;

  ApiClient({
    required SecureTokenStorage storage,
    required this.sessionManager,
    Dio? dio,
  }) {
    _dio = dio ??
        Dio(BaseOptions(
          baseUrl: ApiConstants.baseUrl,
          connectTimeout:
              const Duration(milliseconds: ApiConstants.connectTimeout),
          receiveTimeout:
              const Duration(milliseconds: ApiConstants.receiveTimeout),
          sendTimeout:
              const Duration(milliseconds: ApiConstants.sendTimeout),
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          validateStatus: (_) => true, // Let us handle all status codes.
        ));

    _dio.interceptors.add(
      AuthInterceptor(storage: storage, sessionManager: sessionManager),
    );
  }

  /// Expose Dio for testing or advanced usage.
  Dio get dio => _dio;

  // ═══════════════════════════════════════════════════════════════════
  // Public API
  // ═══════════════════════════════════════════════════════════════════

  /// HTTP GET that returns parsed [BaseResponse<T>].
  Future<BaseResponse<T>> get<T>(
    String path, {
    T Function(Object? json)? fromJson,
    Map<String, dynamic>? queryParameters,
  }) async {
    return _execute<T>(
      () => _dio.get(path, queryParameters: queryParameters),
      fromJson: fromJson,
    );
  }

  /// HTTP POST that returns parsed [BaseResponse<T>].
  Future<BaseResponse<T>> post<T>(
    String path, {
    T Function(Object? json)? fromJson,
    Map<String, dynamic>? data,
  }) async {
    return _execute<T>(
      () => _dio.post(path, data: data),
      fromJson: fromJson,
    );
  }

  /// HTTP PUT that returns parsed [BaseResponse<T>].
  Future<BaseResponse<T>> put<T>(
    String path, {
    T Function(Object? json)? fromJson,
    Map<String, dynamic>? data,
  }) async {
    return _execute<T>(
      () => _dio.put(path, data: data),
      fromJson: fromJson,
    );
  }

  /// HTTP DELETE that returns parsed [BaseResponse<T>].
  Future<BaseResponse<T>> delete<T>(
    String path, {
    T Function(Object? json)? fromJson,
  }) async {
    return _execute<T>(
      () => _dio.delete(path),
      fromJson: fromJson,
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  // Core Execution
  // ═══════════════════════════════════════════════════════════════════

  Future<BaseResponse<T>> _execute<T>(
    Future<Response> Function() request, {
    T Function(Object? json)? fromJson,
  }) async {
    try {
      final response = await request();
      final json = response.data;

      if (json is! Map<String, dynamic>) {
        throw const ServerException(
          message: 'Unexpected response format from server.',
        );
      }

      final baseResponse = BaseResponse<T>.fromJson(json, fromJson);

      // If the response is an error, throw the mapped exception.
      if (baseResponse.isError && baseResponse.code != null) {
        throw ExceptionMapper.fromResponse(
          code: baseResponse.code!,
          message: baseResponse.message,
          traceId: baseResponse.traceId,
          details: baseResponse.details,
          statusCode: response.statusCode,
        );
      }

      return baseResponse;
    } on ApiException {
      rethrow;
    } on DioException catch (e) {
      throw _mapDioException(e);
    } on SocketException {
      throw const NetworkException();
    }
  }

  /// Map Dio-level errors to our exception hierarchy.
  ApiException _mapDioException(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return const TimeoutException();
      case DioExceptionType.connectionError:
        return const NetworkException();
      case DioExceptionType.badResponse:
        // Try to parse the error body.
        final data = e.response?.data;
        if (data is Map<String, dynamic> && data.containsKey('code')) {
          return ExceptionMapper.fromResponse(
            code: data['code'] as String,
            message: data['message'] as String? ?? 'Unknown error',
            traceId: data['trace_id'] as String?,
            details: data['details'] is Map
                ? Map<String, dynamic>.from(data['details'] as Map)
                : null,
            statusCode: e.response?.statusCode,
          );
        }
        return ServerException(
          message: 'Server error: ${e.response?.statusCode}',
        );
      default:
        return const ServerException(
          message: 'An unexpected network error occurred.',
        );
    }
  }
}
